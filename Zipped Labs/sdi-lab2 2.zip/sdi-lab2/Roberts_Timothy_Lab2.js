alert("JavaScript works!");

/*
Timothy Roberts
May 7, 2015
SDI 1505
Lab 2: Variables and Outputs
 */

// These are my variables.
var myTransportation = "Bike";
var howToGetSchool = " I will need to \"pedal\"";
var minutesToSchool = 20;
var itTakesOnly = true;
minutesToSchool = prompt ("Can it be as fast as 5 minutes to arrive to school?");


itTakesOnly = confirm(" It really doesn't take longer than 20 minutes to get to school? Click OK to agree, Cancel to disagree no.");


// These are my outputs.
console.log(" I get to school by using my  " + myTransportation + ".");
console.log( howToGetSchool + "my bike to get to school.");
console.log(" It takes " + minutesToSchool + " minutes to arrive at the school.");
console.log(" It doesn't take any longer than 20 minutes: " + itTakesOnly);
console.log( minutesToSchool + " , it can/can't be. ");

